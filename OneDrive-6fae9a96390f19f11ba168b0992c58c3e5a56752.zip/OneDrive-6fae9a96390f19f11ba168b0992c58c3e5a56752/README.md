# OneDrive on Bash

-------------------------------------------------------------------------

#Install-[OneDrive for Personal]
```
wget --no-check-certificate -q -O /tmp/OneDrive.sh "https://raw.githubusercontent.com/0oVicero0/OneDrive/master/OneDrive.sh" && bash /tmp/OneDrive.sh "personal"

```

#Install-[OneDrive for Business]
```
wget --no-check-certificate -q -O /tmp/OneDrive.sh "https://raw.githubusercontent.com/0oVicero0/OneDrive/master/OneDrive.sh" && bash /tmp/OneDrive.sh "business"

```

